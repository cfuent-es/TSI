#!/bin/bash

# Compilar os arquivos Java
javac Aresta.java Grafo.java Main.java Vertice.java LoadingAnimation.java

# Executar o programa
java Main