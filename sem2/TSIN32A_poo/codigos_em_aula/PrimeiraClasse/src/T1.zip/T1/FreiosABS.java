public class FreiosABS extends Freios {

    private String tipo = "ABS";
    
    public FreiosABS() {
        super(2000);
    }

    public String getTipo() {
        return tipo;
    }

}
