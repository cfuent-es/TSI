import java.math.BigDecimal;

public class Relatorio {
    private int totalVeiculos;
    private BigDecimal totalValorVeiculos;
    private BigDecimal aliquotaImposto;
    private BigDecimal totalImposto;
}
