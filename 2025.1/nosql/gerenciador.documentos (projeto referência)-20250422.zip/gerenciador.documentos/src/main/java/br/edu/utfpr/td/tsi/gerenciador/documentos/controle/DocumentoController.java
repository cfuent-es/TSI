package br.edu.utfpr.td.tsi.gerenciador.documentos.controle;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.edu.utfpr.td.tsi.gerenciador.documentos.modelo.Documento;
import br.edu.utfpr.td.tsi.gerenciador.documentos.persistencia.BancoDados;

@Controller
public class DocumentoController {

	private BancoDados bancoDados = new BancoDados();

	@GetMapping(value = "/cadastrarDocumento")
	public String exibirPaginaCadastrarDocumento() {
		return "cadastrarDocumento";
	}

	@PostMapping(value = "/cadastrarDocumento")
	public String cadastrarDocumento(Documento documento) {
		bancoDados.persistirDocumento(documento);
		return "index";
	}

	@GetMapping(value = "/listarDocumentos")
	public String exibirPaginaListarDocumentos(Model model) {
		List<Documento> documentos = bancoDados.listarDocumentos();
		model.addAttribute("documentos", documentos);
		return "listarDocumentos";
	}

	@GetMapping(value = "/removerDocumento")
	public String removerDocumentos(@RequestParam String idDocumento) {
		System.out.println("removendo documento de id " + idDocumento);
		bancoDados.removerDocumento(idDocumento);
		return "index";
	}

}
