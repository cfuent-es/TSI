package es.cfuent.documents_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentsManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(DocumentsManagerApplication.class, args);
    }
}